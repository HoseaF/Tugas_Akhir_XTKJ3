package com.example.smartshopping;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    private EditText etUsername, etPass;
    private Button btnLogin;
    private TextView tvReg;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        db = new DatabaseHelper(this);
        etUsername = (EditText)findViewById(R.id.etUsername);
        etPass = (EditText)findViewById(R.id.etPass);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        tvReg = (TextView)findViewById(R.id.tvReg);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username, password;

                username = etUsername.getText().toString();
                password = etPass.getText().toString();

                if (username.equals(""))
                {
                    Toast.makeText(HomeActivity.this, "Username Required",Toast.LENGTH_SHORT).show();
                }else if(password.equals("")){
                    Toast.makeText(HomeActivity.this, "Password Required",Toast.LENGTH_SHORT).show();
                }else{
                    //authentication
                    Boolean checkusernamepassword = db.usernamepassword(username, password);
                    if(checkusernamepassword==true){
                        Toast.makeText(getApplicationContext(),"Successfully Login", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(HomeActivity.this, MainMenu.class);
                        startActivity(i);
                    }else{
                        Toast.makeText(getApplicationContext(),"Wrong email or password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        tvReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, Register.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
