package com.example.smartshopping;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Register extends AppCompatActivity {
    private EditText etPass, etConfirm, etUsername;
    Button btnRegister;
    DatabaseHelper  db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        etPass = (EditText)findViewById(R.id.etPass);
        db = new DatabaseHelper(this);
        etUsername = (EditText)findViewById(R.id.etUsername);
        etConfirm = (EditText)findViewById(R.id.etConfirm);
        btnRegister = (Button)findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password, username, confirm;

                password = etPass.getText().toString();
                username = etUsername.getText().toString();
                confirm = etConfirm.getText().toString();

                if (username.equals(""))
                {
                    Toast.makeText(Register.this, "Name Required",Toast.LENGTH_SHORT).show();
                }else if(password.equals("")){
                    Toast.makeText(Register.this, "Password Required",Toast.LENGTH_SHORT).show();
                }else if(confirm.equals("")){
                    Toast.makeText(Register.this, "Confirm Password",Toast.LENGTH_SHORT).show();
                }else if(!confirm.equals(password)){
                    Toast.makeText(Register.this, "Password Mismatch",Toast.LENGTH_SHORT).show();
                }else{
                    //authentication
                    Boolean checkusername = db.checkusername(username);
                    if(checkusername==true){
                        Boolean insert = db.insert(username, password);
                        if(insert==true){
                            Toast.makeText(getApplicationContext(), "Registered Successfully", Toast.LENGTH_SHORT).show();
                            Intent a = new Intent(Register.this, HomeActivity.class);
                            startActivity(a);
                        }
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "User Already Exists", Toast.LENGTH_SHORT).show();
                    }


            }
        }
        }
        );
//
//        btnRegister.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent a = new Intent(Register.this, HomeActivity.class);
//                startActivity(a);
//            }
//        });
    }
}
